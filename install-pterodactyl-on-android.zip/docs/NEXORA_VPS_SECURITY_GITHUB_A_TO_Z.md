# Nexora A to Z: VPS + Security + GitHub Deployment

## 1) VPS Specs

- OS: Ubuntu 22.04 LTS
- Minimum: 2 vCPU, 4 GB RAM, 60 GB SSD
- Domain: `panel.yourdomain.com`, `api.yourdomain.com`

## 2) Base Hardening

```bash
adduser deploy
usermod -aG sudo deploy
mkdir -p /home/deploy/.ssh
nano /home/deploy/.ssh/authorized_keys
chown -R deploy:deploy /home/deploy/.ssh
chmod 700 /home/deploy/.ssh
chmod 600 /home/deploy/.ssh/authorized_keys
```

Edit `/etc/ssh/sshd_config`:

```text
PermitRootLogin no
PasswordAuthentication no
PubkeyAuthentication yes
```

```bash
systemctl restart ssh
apt update && apt upgrade -y
apt install -y ufw fail2ban nginx certbot python3-certbot-nginx postgresql postgresql-contrib
ufw allow OpenSSH
ufw allow 80
ufw allow 443
ufw --force enable
```

## 3) Install Node.js LTS

```bash
curl -fsSL https://deb.nodesource.com/setup_lts.x | sudo -E bash -
apt install -y nodejs build-essential
node -v
npm -v
```

## 4) PostgreSQL Setup

```bash
sudo -u postgres psql
```

```sql
CREATE USER nexora_user WITH PASSWORD 'CHANGE_ME';
CREATE DATABASE nexora_prod OWNER nexora_user;
\q
```

## 5) Project Deploy Folder

```bash
mkdir -p /var/www/nexora
chown -R deploy:deploy /var/www/nexora
cd /var/www/nexora
```

## 6) GitHub Deep Workflow (Yes, you can)

You can fully manage this on GitHub using:

- `main` branch: production
- `develop` branch: staging
- Pull Requests with code review
- GitHub Actions CI/CD
- GitHub Secrets for server credentials and env values

Recommended repos:

- `nexora-frontend`
- `nexora-api`
- Optional: `nexora-daemon`

## 7) Backend Runtime Setup

```bash
cd /var/www/nexora
git clone <your-repo-url> .
npm install
cp .env.example .env
nano .env
```

Set important env values:

- `NODE_ENV=production`
- `PORT=4000`
- `DATABASE_URL=postgres://...`
- `JWT_SECRET=<64+ random chars>`
- `CORS_ORIGINS=https://panel.yourdomain.com`

Run DB schema + seed:

```bash
psql "$DATABASE_URL" -f server/db/init.sql
node server/scripts/seed.mjs
```

## 8) Systemd Service

Create `/etc/systemd/system/nexora-api.service`:

```ini
[Unit]
Description=Nexora API
After=network.target

[Service]
Type=simple
User=deploy
WorkingDirectory=/var/www/nexora
ExecStart=/usr/bin/node server/src/index.js
Restart=always
RestartSec=5
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
```

```bash
systemctl daemon-reload
systemctl enable --now nexora-api
systemctl status nexora-api
```

## 9) Nginx Reverse Proxy

Create `/etc/nginx/sites-available/nexora-api`:

```nginx
server {
  listen 80;
  server_name api.yourdomain.com;

  location / {
    proxy_pass http://127.0.0.1:4000;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection 'upgrade';
    proxy_set_header Host $host;
    proxy_cache_bypass $http_upgrade;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
  }
}
```

```bash
ln -s /etc/nginx/sites-available/nexora-api /etc/nginx/sites-enabled/nexora-api
nginx -t
systemctl reload nginx
certbot --nginx -d api.yourdomain.com
```

## 10) Security Checklist

- Enable 2FA for admin accounts
- Add login failure throttling in DB/Redis
- Keep JWT expiry short for admin sessions
- Rotate secrets every 60-90 days
- Daily encrypted DB backups
- Monthly restore drill
- Configure fail2ban for nginx + ssh
- Keep server patched

## 11) GitHub Actions CI/CD (Recommended)

Pipeline should do:

1. Install dependencies
2. Run tests/lint
3. Build frontend
4. SSH deploy to VPS
5. Restart `nexora-api` service
6. Health check `https://api.yourdomain.com/api/v1/health`

## 11.1) EasyPaisa Transaction Verification (Server Order)

Order and verification sequence:

1. Create order:

```bash
curl -X POST https://api.yourdomain.com/api/v1/billing/orders \
  -H "Authorization: Bearer <TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{
    "serverName":"MC-Premium-01",
    "node":"pk-node-1",
    "cpuLimit":100,
    "ramLimitMb":4096,
    "diskLimitMb":20480,
    "amountPkr":3500
  }'
```

2. Submit transaction ID after payment:

```bash
curl -X POST https://api.yourdomain.com/api/v1/billing/orders/<ORDER_ID>/submit-transaction \
  -H "Authorization: Bearer <TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{
    "transactionId":"EPX77331AB9",
    "senderNumber":"03331234567"
  }'
```

3. Admin verifies transaction ID:

```bash
curl -X POST https://api.yourdomain.com/api/v1/billing/orders/<ORDER_ID>/verify-transaction \
  -H "Authorization: Bearer <ADMIN_TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{
    "status":"approved",
    "adminNote":"Matched against statement",
    "autoProvision":true
  }'
```

Security behavior:

- `transactionId` is unique (cannot be reused across orders)
- only admin can verify
- all actions are written to audit logs

## 12) First API Test

```bash
curl https://api.yourdomain.com/api/v1/health
```

Then login:

```bash
curl -X POST https://api.yourdomain.com/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@nexora.local","password":"Admin@12345"}'
```

If you want, next step is connecting this API to a real daemon for container lifecycle and live usage polling.