import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";

type Language = "en" | "ur";
type Role = "admin" | "reseller";
type Tab = "overview" | "billing" | "api" | "security" | "deploy";
type ServerStatus = "running" | "stopped" | "restarting";

type Theme = {
  id: string;
  name: string;
  bg: string;
  surface: string;
  soft: string;
  border: string;
  text: string;
  muted: string;
  accent: string;
};

type Server = {
  id: number;
  name: string;
  node: string;
  cpu: number;
  ram: number;
  status: ServerStatus;
};

type SecurityItem = {
  id: string;
  titleEn: string;
  titleUr: string;
  done: boolean;
};

const copyText = async (value: string) => {
  try {
    await navigator.clipboard.writeText(value);
    return true;
  } catch {
    return false;
  }
};

const dictionary = {
  en: {
    subtitle: "Production blueprint inspired by Pterodactyl",
    title: "Build, secure, and deploy your panel from phone to VPS",
    role: "Role",
    language: "Language",
    theme: "Theme",
    tabs: {
      overview: "Overview",
      billing: "Billing",
      api: "API",
      security: "Security",
      deploy: "A to Z Deploy",
    },
    online: "Online servers",
    clients: "Active clients",
    monthly: "Monthly revenue",
    nodes: "Nodes",
    actions: "Actions",
    usage: "Usage",
    billingTitle: "EasyPaisa configuration",
    paymentNumber: "Payment Number",
    invoice: "Generate Demo Invoice",
    account: "Account Name",
    amount: "Amount (PKR)",
    invoiceOk: "Demo invoice generated.",
    apiTitle: "Core API routes for production",
    baseUrl: "Base URL",
    copy: "Copy",
    copied: "Copied",
    securityTitle: "Security hardening checklist",
    completion: "Completion",
    deployTitle: "A to Z deployment path",
    note: "This is a real frontend starter. Backend endpoints below should be implemented on VPS.",
  },
  ur: {
    subtitle: "Pterodactyl se inspired production blueprint",
    title: "Phone se VPS tak apna panel build, secure aur deploy karein",
    role: "Role",
    language: "Zabaan",
    theme: "Theme",
    tabs: {
      overview: "Overview",
      billing: "Billing",
      api: "API",
      security: "Security",
      deploy: "A to Z Deploy",
    },
    online: "Online servers",
    clients: "Active clients",
    monthly: "Mahana revenue",
    nodes: "Nodes",
    actions: "Actions",
    usage: "Usage",
    billingTitle: "EasyPaisa configuration",
    paymentNumber: "Payment Number",
    invoice: "Demo Invoice Banayen",
    account: "Account Name",
    amount: "Amount (PKR)",
    invoiceOk: "Demo invoice generate ho gaya.",
    apiTitle: "Production ke liye core API routes",
    baseUrl: "Base URL",
    copy: "Copy",
    copied: "Copied",
    securityTitle: "Security hardening checklist",
    completion: "Completion",
    deployTitle: "A to Z deployment path",
    note: "Yeh real frontend starter hai. Niche wali backend endpoints VPS par implement karni hongi.",
  },
};

const baseThemes: Theme[] = [
  {
    id: "white",
    name: "White",
    bg: "linear-gradient(130deg, #f8fafc 0%, #ffffff 52%, #eef2ff 100%)",
    surface: "rgba(255,255,255,0.8)",
    soft: "rgba(255,255,255,0.62)",
    border: "rgba(15,23,42,0.14)",
    text: "#0f172a",
    muted: "#475569",
    accent: "#4f46e5",
  },
  {
    id: "black",
    name: "Black",
    bg: "linear-gradient(130deg, #020617 0%, #111827 52%, #0f172a 100%)",
    surface: "rgba(15,23,42,0.78)",
    soft: "rgba(30,41,59,0.56)",
    border: "rgba(148,163,184,0.24)",
    text: "#e2e8f0",
    muted: "#94a3b8",
    accent: "#38bdf8",
  },
];

function randomTheme(seed: number): Theme {
  const hue = (seed * 97 + 177) % 360;
  return {
    id: `random-${seed}`,
    name: `Random ${seed}`,
    bg: `linear-gradient(130deg, hsl(${hue} 64% 12%) 0%, hsl(${(hue + 42) % 360} 72% 22%) 55%, hsl(${(hue + 96) % 360} 74% 30%) 100%)`,
    surface: "rgba(15,23,42,0.75)",
    soft: "rgba(30,41,59,0.54)",
    border: "rgba(226,232,240,0.22)",
    text: "#f8fafc",
    muted: "#cbd5e1",
    accent: `hsl(${(hue + 135) % 360} 82% 63%)`,
  };
}

const apiRoutes = [
  ["POST", "/api/v1/auth/login", "Admin/Reseller login + JWT"],
  ["GET", "/api/v1/servers", "List servers by role scope"],
  ["POST", "/api/v1/servers", "Create server"],
  ["POST", "/api/v1/servers/:id/power", "start | stop | restart"],
  ["GET", "/api/v1/servers/:id/resources", "CPU/RAM/Disk live usage"],
  ["GET", "/api/v1/servers/:id/files", "List files (daemon integration scaffold)"],
  ["POST", "/api/v1/servers/:id/backups", "Create backup record"],
  ["PATCH", "/api/v1/servers/:id/startup", "Update startup command + image"],
  ["POST", "/api/v1/billing/orders", "Create paid server order"],
  ["POST", "/api/v1/billing/orders/:orderId/submit-transaction", "Submit EasyPaisa trx ID"],
  ["POST", "/api/v1/billing/orders/:orderId/verify-transaction", "Admin verification + auto provision"],
  ["POST", "/api/v1/billing/payments/easypaisa/verify", "Legacy invoice payment verification"],
  ["GET", "/api/v1/audit-logs", "Security and admin actions"],
];

const deploySteps = [
  "Buy VPS (Ubuntu 22.04, min 4GB RAM) and point domains: panel.yourdomain.com + node.yourdomain.com.",
  "Install reverse proxy and runtime: Nginx, Node.js LTS, PostgreSQL, Redis, Docker, and UFW.",
  "Create PostgreSQL DB and user with strict password and no remote superuser access.",
  "Build backend API (Express/Fastify + JWT + RBAC + zod validation + rate limiting).",
  "Add queue workers for billing verification, backups, and server sync tasks.",
  "Connect panel API to your daemon layer (Docker/Wings style service on node).",
  "Set HTTPS using Cloudflare Full Strict and Let's Encrypt on origin.",
  "Enable security: fail2ban, UFW allowlist, password hashing, 2FA, audit logs, IP throttling.",
  "Set CI/CD: GitHub Actions build, test, migrate, deploy and health check endpoint.",
  "Add monitoring: uptime alerts, structured logs, daily DB backup, restore drill every month.",
];

export default function App() {
  const [language, setLanguage] = useState<Language>("en");
  const [role, setRole] = useState<Role>("admin");
  const [tab, setTab] = useState<Tab>("overview");
  const [invoiceMessage, setInvoiceMessage] = useState("");
  const [copied, setCopied] = useState(false);
  const [servers, setServers] = useState<Server[]>([
    { id: 1, name: "NX-Minecraft-01", node: "Karachi-1", cpu: 44, ram: 63, status: "running" },
    { id: 2, name: "NX-Bot-02", node: "Lahore-2", cpu: 21, ram: 34, status: "stopped" },
    { id: 3, name: "NX-Cloud-03", node: "Islamabad-1", cpu: 59, ram: 71, status: "running" },
  ]);
  const [securityList, setSecurityList] = useState<SecurityItem[]>([
    { id: "2fa", titleEn: "Admin 2FA enabled", titleUr: "Admin 2FA on hai", done: true },
    { id: "rbac", titleEn: "Strict RBAC for admin/reseller", titleUr: "Admin/reseller RBAC strict hai", done: true },
    { id: "ratelimit", titleEn: "API rate limiting and brute-force lock", titleUr: "API rate limit aur brute lock", done: false },
    { id: "backup", titleEn: "Automated DB backups (daily)", titleUr: "Automated DB backup (daily)", done: false },
    { id: "audit", titleEn: "Immutable audit trail", titleUr: "Immutable audit trail", done: true },
  ]);

  const themes = useMemo(() => [...baseThemes, randomTheme(1), randomTheme(2), randomTheme(3)], []);
  const [themeId, setThemeId] = useState(themes[1].id);
  const currentTheme = themes.find((th) => th.id === themeId) ?? themes[0];
  const t = dictionary[language];
  const runningServers = servers.filter((server) => server.status === "running").length;
  const completedSecurity = securityList.filter((item) => item.done).length;
  const securityPercent = Math.round((completedSecurity / securityList.length) * 100);
  const baseUrl = "https://api.nexorapanel.com";

  const mutateServer = (id: number, action: "start" | "stop" | "restart") => {
    setServers((state) =>
      state.map((server) => {
        if (server.id !== id) return server;
        if (action === "start") return { ...server, status: "running" };
        if (action === "stop") return { ...server, status: "stopped" };
        return { ...server, status: "restarting" };
      })
    );

    if (action === "restart") {
      setTimeout(() => {
        setServers((state) => state.map((server) => (server.id === id ? { ...server, status: "running" } : server)));
      }, 1000);
    }
  };

  return (
    <div className="min-h-screen p-4 md:p-8" style={{ background: currentTheme.bg, color: currentTheme.text }}>
      <motion.div
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45 }}
        className="mx-auto max-w-7xl rounded-3xl border p-4 backdrop-blur-xl md:p-6"
        style={{ backgroundColor: currentTheme.surface, borderColor: currentTheme.border }}
      >
        <header className="flex flex-col gap-4 border-b pb-5 md:flex-row md:items-end md:justify-between" style={{ borderColor: currentTheme.border }}>
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.26em]" style={{ color: currentTheme.muted }}>
              Nexora Panel
            </p>
            <h1 className="mt-2 text-2xl font-semibold md:text-4xl">{t.title}</h1>
            <p className="mt-2 text-sm md:text-base" style={{ color: currentTheme.muted }}>
              {t.subtitle}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <select
              aria-label={t.language}
              value={language}
              onChange={(event) => setLanguage(event.target.value as Language)}
              className="rounded-full border px-3 py-1.5 text-sm"
              style={{ backgroundColor: currentTheme.soft, borderColor: currentTheme.border, color: currentTheme.text }}
            >
              <option value="en">English</option>
              <option value="ur">Urdu</option>
            </select>
            <select
              aria-label={t.role}
              value={role}
              onChange={(event) => setRole(event.target.value as Role)}
              className="rounded-full border px-3 py-1.5 text-sm"
              style={{ backgroundColor: currentTheme.soft, borderColor: currentTheme.border, color: currentTheme.text }}
            >
              <option value="admin">Admin</option>
              <option value="reseller">Reseller</option>
            </select>
            <select
              aria-label={t.theme}
              value={themeId}
              onChange={(event) => setThemeId(event.target.value)}
              className="rounded-full border px-3 py-1.5 text-sm"
              style={{ backgroundColor: currentTheme.soft, borderColor: currentTheme.border, color: currentTheme.text }}
            >
              {themes.map((theme) => (
                <option value={theme.id} key={theme.id}>
                  {theme.name}
                </option>
              ))}
            </select>
          </div>
        </header>

        <nav className="mt-5 flex flex-wrap gap-2">
          {(Object.keys(t.tabs) as Tab[]).map((item) => (
            <button
              key={item}
              onClick={() => setTab(item)}
              className="rounded-full border px-4 py-1.5 text-sm"
              style={{
                borderColor: currentTheme.border,
                backgroundColor: tab === item ? currentTheme.accent : currentTheme.soft,
                color: tab === item ? "#ffffff" : currentTheme.text,
              }}
            >
              {t.tabs[item]}
            </button>
          ))}
        </nav>

        <AnimatePresence mode="wait">
          <motion.main
            key={tab + language + role + themeId}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.25 }}
            className="mt-5"
          >
            {tab === "overview" && (
              <section className="space-y-3">
                <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
                  {[
                    [t.online, `${runningServers} / ${servers.length}`],
                    [t.clients, role === "admin" ? "143" : "34"],
                    [t.monthly, "PKR 228,000"],
                    [t.nodes, "3"],
                  ].map(([name, value]) => (
                    <div key={name} className="rounded-xl border p-3" style={{ borderColor: currentTheme.border, backgroundColor: currentTheme.soft }}>
                      <p className="text-sm" style={{ color: currentTheme.muted }}>
                        {name}
                      </p>
                      <p className="text-2xl font-semibold">{value}</p>
                    </div>
                  ))}
                </div>

                <div className="space-y-2 rounded-xl border p-3" style={{ borderColor: currentTheme.border, backgroundColor: currentTheme.soft }}>
                  {servers.map((server) => (
                    <div key={server.id} className="flex flex-col gap-2 border-b pb-2 last:border-b-0" style={{ borderColor: currentTheme.border }}>
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <p className="font-medium">{server.name}</p>
                        <motion.span
                          animate={{ scale: server.status === "running" ? [1, 1.05, 1] : 1 }}
                          transition={{ duration: 1.2, repeat: server.status === "running" ? Infinity : 0 }}
                          className="text-xs uppercase"
                          style={{
                            color: server.status === "running" ? "#22c55e" : server.status === "restarting" ? "#f59e0b" : "#ef4444",
                          }}
                        >
                          {server.status}
                        </motion.span>
                      </div>
                      <p className="text-sm" style={{ color: currentTheme.muted }}>
                        {server.node} | {t.usage}: CPU {server.cpu}% RAM {server.ram}%
                      </p>
                      <div className="flex gap-2">
                        <button
                          onClick={() => mutateServer(server.id, "start")}
                          className="rounded-full border px-3 py-1 text-xs"
                          style={{ borderColor: currentTheme.border, backgroundColor: currentTheme.surface }}
                        >
                          Start
                        </button>
                        <button
                          onClick={() => mutateServer(server.id, "stop")}
                          className="rounded-full border px-3 py-1 text-xs"
                          style={{ borderColor: currentTheme.border, backgroundColor: currentTheme.surface }}
                        >
                          Stop
                        </button>
                        <button
                          onClick={() => mutateServer(server.id, "restart")}
                          className="rounded-full border px-3 py-1 text-xs"
                          style={{ borderColor: currentTheme.border, backgroundColor: currentTheme.surface }}
                        >
                          Restart
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {tab === "billing" && (
              <section className="grid gap-3 md:grid-cols-2">
                <div className="rounded-xl border p-4" style={{ borderColor: currentTheme.border, backgroundColor: currentTheme.soft }}>
                  <h2 className="text-lg font-semibold">{t.billingTitle}</h2>
                  <p className="mt-4 text-sm" style={{ color: currentTheme.muted }}>
                    {t.paymentNumber}
                  </p>
                  <p className="text-2xl font-semibold">0344-8170040</p>
                </div>
                <form
                  className="space-y-2 rounded-xl border p-4"
                  style={{ borderColor: currentTheme.border, backgroundColor: currentTheme.soft }}
                  onSubmit={(event) => {
                    event.preventDefault();
                    setInvoiceMessage(t.invoiceOk);
                  }}
                >
                  <input
                    required
                    placeholder={t.account}
                    className="w-full rounded-lg border px-3 py-2 text-sm"
                    style={{ borderColor: currentTheme.border, backgroundColor: currentTheme.surface }}
                  />
                  <input
                    required
                    placeholder={t.amount}
                    className="w-full rounded-lg border px-3 py-2 text-sm"
                    style={{ borderColor: currentTheme.border, backgroundColor: currentTheme.surface }}
                  />
                  <button type="submit" className="w-full rounded-lg py-2 text-sm font-medium text-white" style={{ backgroundColor: currentTheme.accent }}>
                    {t.invoice}
                  </button>
                  {invoiceMessage && <p className="text-sm">{invoiceMessage}</p>}
                </form>
              </section>
            )}

            {tab === "api" && (
              <section className="space-y-3 rounded-xl border p-4" style={{ borderColor: currentTheme.border, backgroundColor: currentTheme.soft }}>
                <h2 className="text-lg font-semibold">{t.apiTitle}</h2>
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-sm" style={{ color: currentTheme.muted }}>
                    {t.baseUrl}: {baseUrl}
                  </span>
                  <button
                    className="rounded-full border px-3 py-1 text-xs"
                    style={{ borderColor: currentTheme.border, backgroundColor: currentTheme.surface }}
                    onClick={async () => {
                      const ok = await copyText(baseUrl);
                      setCopied(ok);
                      setTimeout(() => setCopied(false), 1200);
                    }}
                  >
                    {copied ? t.copied : t.copy}
                  </button>
                </div>
                <div className="space-y-2">
                  {apiRoutes.map(([method, path, desc]) => (
                    <div key={path} className="rounded-lg border p-2 text-sm" style={{ borderColor: currentTheme.border, backgroundColor: currentTheme.surface }}>
                      <p>
                        <span className="font-semibold" style={{ color: currentTheme.accent }}>
                          {method}
                        </span>{" "}
                        {path}
                      </p>
                      <p style={{ color: currentTheme.muted }}>{desc}</p>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {tab === "security" && (
              <section className="space-y-3 rounded-xl border p-4" style={{ borderColor: currentTheme.border, backgroundColor: currentTheme.soft }}>
                <h2 className="text-lg font-semibold">{t.securityTitle}</h2>
                <div className="h-2 rounded-full" style={{ backgroundColor: currentTheme.surface }}>
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${securityPercent}%` }}
                    transition={{ duration: 0.5 }}
                    className="h-2 rounded-full"
                    style={{ backgroundColor: currentTheme.accent }}
                  />
                </div>
                <p className="text-sm" style={{ color: currentTheme.muted }}>
                  {t.completion}: {securityPercent}%
                </p>
                {securityList.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setSecurityList((state) => state.map((x) => (x.id === item.id ? { ...x, done: !x.done } : x)))}
                    className="flex w-full items-center justify-between rounded-lg border p-3 text-left text-sm"
                    style={{ borderColor: currentTheme.border, backgroundColor: currentTheme.surface }}
                  >
                    <span>{language === "en" ? item.titleEn : item.titleUr}</span>
                    <span style={{ color: item.done ? "#22c55e" : "#f59e0b" }}>{item.done ? "Done" : "Pending"}</span>
                  </button>
                ))}
              </section>
            )}

            {tab === "deploy" && (
              <section className="space-y-3 rounded-xl border p-4" style={{ borderColor: currentTheme.border, backgroundColor: currentTheme.soft }}>
                <h2 className="text-lg font-semibold">{t.deployTitle}</h2>
                <ol className="space-y-2 text-sm">
                  {deploySteps.map((step, idx) => (
                    <li key={step} className="rounded-lg border p-3" style={{ borderColor: currentTheme.border, backgroundColor: currentTheme.surface }}>
                      <span className="font-semibold" style={{ color: currentTheme.accent }}>
                        {idx + 1}.
                      </span>{" "}
                      {step}
                    </li>
                  ))}
                </ol>
              </section>
            )}
          </motion.main>
        </AnimatePresence>

        <footer className="mt-5 border-t pt-4 text-sm" style={{ borderColor: currentTheme.border, color: currentTheme.muted }}>
          {t.note}
        </footer>
      </motion.div>
    </div>
  );
}
