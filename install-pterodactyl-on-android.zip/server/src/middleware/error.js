import { ZodError } from "zod";

export function notFoundHandler(_req, res) {
  return res.status(404).json({ message: "Route not found" });
}

export function errorHandler(error, _req, res, _next) {
  if (error instanceof ZodError) {
    return res.status(400).json({
      message: "Validation failed",
      issues: error.flatten(),
    });
  }

  const status = Number(error.statusCode ?? 500);
  const message = status >= 500 ? "Internal server error" : error.message;
  return res.status(status).json({ message });
}