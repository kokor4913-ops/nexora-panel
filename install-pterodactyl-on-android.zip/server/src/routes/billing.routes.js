import { Router } from "express";
import { asyncHandler } from "../utils/async-handler.js";
import { requireAuth, requireRole } from "../middleware/auth.js";
import { validate } from "../middleware/validate.js";
import {
  createInvoiceSchema,
  createOrderSchema,
  listOrdersSchema,
  submitOrderTransactionSchema,
  verifyOrderTransactionSchema,
  verifyPaymentSchema,
} from "../schemas/index.js";
import {
  createInvoice,
  createServerOrder,
  listOrders,
  submitOrderTransaction,
  verifyEasypaisa,
  verifyOrderTransaction,
} from "../controllers/billing.controller.js";

const router = Router();

router.use(requireAuth);
router.post("/invoices", validate(createInvoiceSchema), asyncHandler(createInvoice));
router.post("/orders", validate(createOrderSchema), asyncHandler(createServerOrder));
router.get("/orders", validate(listOrdersSchema), asyncHandler(listOrders));
router.post(
  "/orders/:orderId/submit-transaction",
  validate(submitOrderTransactionSchema),
  asyncHandler(submitOrderTransaction)
);
router.post(
  "/orders/:orderId/verify-transaction",
  requireRole("admin"),
  validate(verifyOrderTransactionSchema),
  asyncHandler(verifyOrderTransaction)
);
router.post("/payments/easypaisa/verify", requireRole("admin"), validate(verifyPaymentSchema), asyncHandler(verifyEasypaisa));

export default router;