import { Router } from "express";
import { asyncHandler } from "../utils/async-handler.js";
import { listAuditLogs } from "../controllers/audit.controller.js";
import { requireAuth, requireRole } from "../middleware/auth.js";
import { validate } from "../middleware/validate.js";
import { auditQuerySchema } from "../schemas/index.js";

const router = Router();

router.get("/", requireAuth, requireRole("admin", "reseller"), validate(auditQuerySchema), asyncHandler(listAuditLogs));

export default router;