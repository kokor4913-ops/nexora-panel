import { Router } from "express";
import { asyncHandler } from "../utils/async-handler.js";
import { login, me } from "../controllers/auth.controller.js";
import { validate } from "../middleware/validate.js";
import { loginSchema } from "../schemas/index.js";
import { requireAuth } from "../middleware/auth.js";

const router = Router();

router.post("/login", validate(loginSchema), asyncHandler(login));
router.get("/me", requireAuth, asyncHandler(me));

export default router;