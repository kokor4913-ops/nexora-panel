import { Router } from "express";
import { asyncHandler } from "../utils/async-handler.js";
import {
  createAllocation,
  createBackup,
  createServer,
  createSubuser,
  getResources,
  getStartup,
  listAllocations,
  listBackups,
  listFiles,
  listServers,
  listSubusers,
  powerAction,
  updateStartup,
} from "../controllers/server.controller.js";
import { requireAuth, requireRole } from "../middleware/auth.js";
import { validate } from "../middleware/validate.js";
import {
  createAllocationSchema,
  createBackupSchema,
  createServerSchema,
  createSubuserSchema,
  listFilesSchema,
  powerActionSchema,
  resourceParamsSchema,
  serverIdParamsSchema,
  updateStartupSchema,
} from "../schemas/index.js";

const router = Router();

router.use(requireAuth);
router.get("/", asyncHandler(listServers));
router.post("/", requireRole("admin", "reseller"), validate(createServerSchema), asyncHandler(createServer));
router.post("/:id/power", validate(powerActionSchema), asyncHandler(powerAction));
router.get("/:id/resources", validate(resourceParamsSchema), asyncHandler(getResources));
router.get("/:id/files", validate(listFilesSchema), asyncHandler(listFiles));
router.get("/:id/backups", validate(serverIdParamsSchema), asyncHandler(listBackups));
router.post("/:id/backups", validate(createBackupSchema), asyncHandler(createBackup));
router.get("/:id/startup", validate(serverIdParamsSchema), asyncHandler(getStartup));
router.patch("/:id/startup", validate(updateStartupSchema), asyncHandler(updateStartup));
router.get("/:id/network/allocations", validate(serverIdParamsSchema), asyncHandler(listAllocations));
router.post("/:id/network/allocations", validate(createAllocationSchema), asyncHandler(createAllocation));
router.get("/:id/subusers", validate(serverIdParamsSchema), asyncHandler(listSubusers));
router.post("/:id/subusers", validate(createSubuserSchema), asyncHandler(createSubuser));

export default router;