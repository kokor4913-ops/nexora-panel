import { Router } from "express";
import authRoutes from "./auth.routes.js";
import serverRoutes from "./server.routes.js";
import billingRoutes from "./billing.routes.js";
import auditRoutes from "./audit.routes.js";

const router = Router();

router.get("/health", (_req, res) => {
  res.json({ ok: true, service: "nexora-api", timestamp: new Date().toISOString() });
});

router.use("/auth", authRoutes);
router.use("/servers", serverRoutes);
router.use("/billing", billingRoutes);
router.use("/audit-logs", auditRoutes);

export default router;