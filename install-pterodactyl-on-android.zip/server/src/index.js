import app from "./app.js";
import { env } from "./config/env.js";
import { pool } from "./db/pool.js";

async function start() {
  try {
    await pool.query("SELECT 1");
    app.listen(env.port, () => {
      // Boot log kept short for PM2/systemd output.
      console.log(`Nexora API listening on port ${env.port}`);
    });
  } catch (error) {
    console.error("Failed to start API:", error);
    process.exit(1);
  }
}

start();