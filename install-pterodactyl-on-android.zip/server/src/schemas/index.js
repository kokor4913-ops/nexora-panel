import { z } from "zod";

const roleEnum = z.enum(["admin", "reseller"]);
const serverStatusEnum = z.enum(["running", "stopped", "restarting"]);
const powerActionEnum = z.enum(["start", "stop", "restart"]);
const orderStatusEnum = z.enum(["pending_payment", "paid", "rejected", "provisioned"]);

export const loginSchema = z.object({
  body: z.object({
    email: z.string().email(),
    password: z.string().min(8),
  }),
  params: z.object({}),
  query: z.object({}),
});

export const createServerSchema = z.object({
  body: z.object({
    name: z.string().min(3).max(64),
    node: z.string().min(2).max(64),
    ownerId: z.string().uuid().optional(),
    cpuLimit: z.number().int().min(5).max(400),
    ramLimitMb: z.number().int().min(256).max(65536),
    diskLimitMb: z.number().int().min(1024).max(1048576),
    status: serverStatusEnum.optional(),
  }),
  params: z.object({}),
  query: z.object({}),
});

export const powerActionSchema = z.object({
  body: z.object({ action: powerActionEnum }),
  params: z.object({ id: z.string().uuid() }),
  query: z.object({}),
});

export const resourceParamsSchema = z.object({
  body: z.object({}),
  params: z.object({ id: z.string().uuid() }),
  query: z.object({}),
});

export const serverIdParamsSchema = z.object({
  body: z.object({}),
  params: z.object({ id: z.string().uuid() }),
  query: z.object({}),
});

export const listFilesSchema = z.object({
  body: z.object({}),
  params: z.object({ id: z.string().uuid() }),
  query: z.object({ path: z.string().min(1).default("/") }),
});

export const createBackupSchema = z.object({
  body: z.object({ name: z.string().min(3).max(80) }),
  params: z.object({ id: z.string().uuid() }),
  query: z.object({}),
});

export const updateStartupSchema = z.object({
  body: z.object({
    dockerImage: z.string().min(5).max(120),
    startupCommand: z.string().min(1).max(500),
  }),
  params: z.object({ id: z.string().uuid() }),
  query: z.object({}),
});

export const createAllocationSchema = z.object({
  body: z.object({ ip: z.string().ip(), port: z.number().int().min(1).max(65535) }),
  params: z.object({ id: z.string().uuid() }),
  query: z.object({}),
});

export const createSubuserSchema = z.object({
  body: z.object({
    email: z.string().email(),
    permissions: z.array(z.string().min(3)).min(1),
  }),
  params: z.object({ id: z.string().uuid() }),
  query: z.object({}),
});

export const createInvoiceSchema = z.object({
  body: z.object({
    clientName: z.string().min(2).max(80),
    amountPkr: z.number().positive().max(10000000),
    note: z.string().max(200).optional(),
  }),
  params: z.object({}),
  query: z.object({}),
});

export const verifyPaymentSchema = z.object({
  body: z.object({
    invoiceId: z.string().uuid(),
    transactionRef: z.string().min(4).max(120),
    screenshotUrl: z.string().url().optional(),
    status: z.enum(["paid", "rejected"]),
  }),
  params: z.object({}),
  query: z.object({}),
});

export const createOrderSchema = z.object({
  body: z.object({
    serverName: z.string().min(3).max(64),
    node: z.string().min(2).max(64),
    cpuLimit: z.number().int().min(5).max(400),
    ramLimitMb: z.number().int().min(256).max(65536),
    diskLimitMb: z.number().int().min(1024).max(1048576),
    amountPkr: z.number().positive().max(10000000),
    note: z.string().max(300).optional(),
  }),
  params: z.object({}),
  query: z.object({}),
});

export const orderParamsSchema = z.object({
  body: z.object({}),
  params: z.object({ orderId: z.string().uuid() }),
  query: z.object({}),
});

export const submitOrderTransactionSchema = z.object({
  body: z.object({
    transactionId: z
      .string()
      .min(6)
      .max(80)
      .regex(/^[a-zA-Z0-9_-]+$/, "transactionId must be alphanumeric with optional _ or -"),
    senderNumber: z
      .string()
      .min(11)
      .max(15)
      .regex(/^[0-9+]+$/, "senderNumber must be numeric"),
    screenshotUrl: z.string().url().optional(),
  }),
  params: z.object({ orderId: z.string().uuid() }),
  query: z.object({}),
});

export const verifyOrderTransactionSchema = z.object({
  body: z.object({
    status: z.enum(["approved", "rejected"]),
    adminNote: z.string().max(300).optional(),
    autoProvision: z.boolean().optional(),
  }),
  params: z.object({ orderId: z.string().uuid() }),
  query: z.object({}),
});

export const listOrdersSchema = z.object({
  body: z.object({}),
  params: z.object({}),
  query: z.object({
    status: orderStatusEnum.optional(),
    limit: z.coerce.number().int().min(1).max(100).default(25),
  }),
});

export const auditQuerySchema = z.object({
  body: z.object({}),
  params: z.object({}),
  query: z.object({
    limit: z.coerce.number().int().min(1).max(200).default(50),
    actorRole: roleEnum.optional(),
  }),
});