import { query } from "../db/pool.js";
import { env } from "../config/env.js";
import { logAudit } from "../services/audit.service.js";

function canAccessOrder(user, order) {
  if (user.role === "admin") return true;
  return order.ordered_by === user.sub;
}

export async function createInvoice(req, res) {
  const user = req.user;
  const { clientName, amountPkr, note } = req.body;

  const result = await query(
    `
      INSERT INTO invoices (client_name, amount_pkr, status, created_by, note)
      VALUES ($1, $2, 'pending', $3, $4)
      RETURNING id, client_name, amount_pkr, status, note, created_at
    `,
    [clientName, amountPkr, user.sub, note ?? null]
  );

  await logAudit({
    actorId: user.sub,
    action: "billing.invoice.create",
    targetType: "invoice",
    targetId: result.rows[0].id,
    details: { amountPkr },
  });

  return res.status(201).json({
    item: result.rows[0],
    easypaisa: {
      number: env.easypaisaNumber,
      instructions: "Client pays manually, then upload transaction proof for admin verification.",
    },
  });
}

export async function verifyEasypaisa(req, res) {
  const user = req.user;
  const { invoiceId, transactionRef, screenshotUrl, status } = req.body;

  const invoice = await query(`SELECT id, status FROM invoices WHERE id = $1 LIMIT 1`, [invoiceId]);
  const row = invoice.rows[0];
  if (!row) {
    return res.status(404).json({ message: "Invoice not found" });
  }

  if (row.status === "paid") {
    return res.status(409).json({ message: "Invoice already paid" });
  }

  await query(
    `
      INSERT INTO payments (invoice_id, method, transaction_ref, screenshot_url, verified_by, status)
      VALUES ($1, 'easypaisa', $2, $3, $4, $5)
      RETURNING id, invoice_id, method, transaction_ref, status, created_at
    `,
    [invoiceId, transactionRef, screenshotUrl ?? null, user.sub, status]
  );

  await query(`UPDATE invoices SET status = $1, updated_at = NOW() WHERE id = $2`, [status, invoiceId]);

  await logAudit({
    actorId: user.sub,
    action: "billing.easypaisa.verify",
    targetType: "invoice",
    targetId: invoiceId,
    details: { transactionRef, status },
  });

  return res.json({ message: "Payment verification saved", invoiceId, status });
}

export async function createServerOrder(req, res) {
  const user = req.user;
  const { serverName, node, cpuLimit, ramLimitMb, diskLimitMb, amountPkr, note } = req.body;

  const created = await query(
    `
      INSERT INTO server_orders (
        ordered_by,
        server_name,
        node,
        cpu_limit,
        ram_limit_mb,
        disk_limit_mb,
        amount_pkr,
        note
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING id, ordered_by, server_name, node, cpu_limit, ram_limit_mb, disk_limit_mb, amount_pkr, status, note, created_at
    `,
    [user.sub, serverName, node, cpuLimit, ramLimitMb, diskLimitMb, amountPkr, note ?? null]
  );

  await logAudit({
    actorId: user.sub,
    action: "billing.order.create",
    targetType: "server_order",
    targetId: created.rows[0].id,
    details: { amountPkr, serverName, node },
  });

  return res.status(201).json({
    item: created.rows[0],
    payment: {
      method: "easypaisa",
      number: env.easypaisaNumber,
      required: "Submit transactionId after transfer for verification.",
    },
  });
}

export async function listOrders(req, res) {
  const user = req.user;
  const { status, limit = 25 } = req.query;

  const params = [];
  const where = [];

  if (user.role !== "admin") {
    params.push(user.sub);
    where.push(`ordered_by = $${params.length}`);
  }

  if (status) {
    params.push(status);
    where.push(`status = $${params.length}`);
  }

  params.push(limit);

  const sql = `
    SELECT id, ordered_by, server_name, node, cpu_limit, ram_limit_mb, disk_limit_mb, amount_pkr, status, paid_at, provisioned_server_id, created_at
    FROM server_orders
    ${where.length ? `WHERE ${where.join(" AND ")}` : ""}
    ORDER BY created_at DESC
    LIMIT $${params.length}
  `;

  const result = await query(sql, params);
  return res.json({ items: result.rows });
}

export async function submitOrderTransaction(req, res) {
  const user = req.user;
  const { orderId } = req.params;
  const { transactionId, senderNumber, screenshotUrl } = req.body;

  const orderResult = await query(`SELECT * FROM server_orders WHERE id = $1 LIMIT 1`, [orderId]);
  const order = orderResult.rows[0];
  if (!order) {
    return res.status(404).json({ message: "Order not found" });
  }

  if (!canAccessOrder(user, order)) {
    return res.status(403).json({ message: "Forbidden" });
  }

  if (order.status === "paid" || order.status === "provisioned") {
    return res.status(409).json({ message: "Order already paid" });
  }

  const duplicate = await query(
    `SELECT id FROM order_transactions WHERE LOWER(transaction_id) = LOWER($1) LIMIT 1`,
    [transactionId]
  );

  if (duplicate.rows[0]) {
    return res.status(409).json({ message: "Transaction ID already used" });
  }

  const created = await query(
    `
      INSERT INTO order_transactions (order_id, transaction_id, sender_number, screenshot_url)
      VALUES ($1, $2, $3, $4)
      RETURNING id, order_id, transaction_id, sender_number, screenshot_url, review_status, created_at
    `,
    [orderId, transactionId, senderNumber, screenshotUrl ?? null]
  );

  await logAudit({
    actorId: user.sub,
    action: "billing.order.transaction.submit",
    targetType: "server_order",
    targetId: orderId,
    details: { transactionId, senderNumber },
  });

  return res.status(201).json({
    message: "Transaction submitted. Awaiting admin review.",
    item: created.rows[0],
  });
}

export async function verifyOrderTransaction(req, res) {
  const user = req.user;
  const { orderId } = req.params;
  const { status, adminNote, autoProvision = true } = req.body;

  const orderResult = await query(`SELECT * FROM server_orders WHERE id = $1 LIMIT 1`, [orderId]);
  const order = orderResult.rows[0];

  if (!order) {
    return res.status(404).json({ message: "Order not found" });
  }

  const txResult = await query(
    `
      SELECT *
      FROM order_transactions
      WHERE order_id = $1
      ORDER BY created_at DESC
      LIMIT 1
    `,
    [orderId]
  );

  const tx = txResult.rows[0];
  if (!tx) {
    return res.status(400).json({ message: "No transaction submitted for this order" });
  }

  if (tx.review_status !== "pending") {
    return res.status(409).json({ message: "Latest transaction is already reviewed" });
  }

  await query(
    `
      UPDATE order_transactions
      SET review_status = $1, reviewed_by = $2, admin_note = $3, reviewed_at = NOW()
      WHERE id = $4
    `,
    [status, user.sub, adminNote ?? null, tx.id]
  );

  if (status === "rejected") {
    await query(
      `UPDATE server_orders SET status = 'rejected', updated_at = NOW() WHERE id = $1`,
      [orderId]
    );

    await logAudit({
      actorId: user.sub,
      action: "billing.order.transaction.reject",
      targetType: "server_order",
      targetId: orderId,
      details: { transactionId: tx.transaction_id, adminNote: adminNote ?? null },
    });

    return res.json({ message: "Transaction rejected", orderId, status: "rejected" });
  }

  const paidUpdate = await query(
    `
      UPDATE server_orders
      SET status = 'paid', paid_at = NOW(), updated_at = NOW()
      WHERE id = $1
      RETURNING *
    `,
    [orderId]
  );

  let provisionedServerId = null;

  if (autoProvision) {
    const provision = await query(
      `
        INSERT INTO servers (name, node, owner_id, reseller_id, cpu_limit, ram_limit_mb, disk_limit_mb, status)
        VALUES ($1, $2, $3, $4, $5, $6, $7, 'stopped')
        RETURNING id
      `,
      [
        paidUpdate.rows[0].server_name,
        paidUpdate.rows[0].node,
        paidUpdate.rows[0].ordered_by,
        paidUpdate.rows[0].ordered_by,
        paidUpdate.rows[0].cpu_limit,
        paidUpdate.rows[0].ram_limit_mb,
        paidUpdate.rows[0].disk_limit_mb,
      ]
    );

    provisionedServerId = provision.rows[0].id;

    await query(
      `
        UPDATE server_orders
        SET status = 'provisioned', provisioned_server_id = $1, updated_at = NOW()
        WHERE id = $2
      `,
      [provisionedServerId, orderId]
    );
  }

  await logAudit({
    actorId: user.sub,
    action: "billing.order.transaction.approve",
    targetType: "server_order",
    targetId: orderId,
    details: {
      transactionId: tx.transaction_id,
      autoProvision,
      provisionedServerId,
    },
  });

  return res.json({
    message: "Transaction approved",
    orderId,
    status: provisionedServerId ? "provisioned" : "paid",
    provisionedServerId,
  });
}