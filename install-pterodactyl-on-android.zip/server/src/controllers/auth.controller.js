import bcrypt from "bcryptjs";
import { query } from "../db/pool.js";
import { signAccessToken } from "../utils/jwt.js";
import { logAudit } from "../services/audit.service.js";

export async function login(req, res) {
  const { email, password } = req.body;

  const result = await query(
    `
      SELECT id, full_name, email, role, password_hash, reseller_id
      FROM users
      WHERE email = $1 AND is_active = true
      LIMIT 1
    `,
    [email]
  );

  const user = result.rows[0];
  if (!user) {
    return res.status(401).json({ message: "Invalid credentials" });
  }

  const valid = await bcrypt.compare(password, user.password_hash);
  if (!valid) {
    return res.status(401).json({ message: "Invalid credentials" });
  }

  const token = signAccessToken({
    sub: user.id,
    email: user.email,
    role: user.role,
    resellerId: user.reseller_id,
  });

  await logAudit({
    actorId: user.id,
    action: "auth.login",
    targetType: "user",
    targetId: user.id,
    details: { email: user.email },
  });

  return res.json({
    token,
    user: {
      id: user.id,
      fullName: user.full_name,
      email: user.email,
      role: user.role,
      resellerId: user.reseller_id,
    },
  });
}

export async function me(req, res) {
  const userId = req.user.sub;
  const result = await query(
    `
      SELECT id, full_name, email, role, reseller_id
      FROM users
      WHERE id = $1
      LIMIT 1
    `,
    [userId]
  );

  if (!result.rows[0]) {
    return res.status(404).json({ message: "User not found" });
  }

  return res.json({ user: result.rows[0] });
}