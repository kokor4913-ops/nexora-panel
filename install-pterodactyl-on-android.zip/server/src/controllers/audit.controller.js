import { query } from "../db/pool.js";

export async function listAuditLogs(req, res) {
  const user = req.user;
  const { limit } = req.query;

  const result =
    user.role === "admin"
      ? await query(
          `
            SELECT a.id, a.action, a.target_type, a.target_id, a.details, a.created_at,
                   u.full_name AS actor_name, u.role AS actor_role
            FROM audit_logs a
            LEFT JOIN users u ON u.id = a.actor_id
            ORDER BY a.created_at DESC
            LIMIT $1
          `,
          [limit]
        )
      : await query(
          `
            SELECT a.id, a.action, a.target_type, a.target_id, a.details, a.created_at,
                   u.full_name AS actor_name, u.role AS actor_role
            FROM audit_logs a
            LEFT JOIN users u ON u.id = a.actor_id
            WHERE a.actor_id = $1
            ORDER BY a.created_at DESC
            LIMIT $2
          `,
          [user.sub, limit]
        );

  return res.json({ items: result.rows });
}