import { query, withTransaction } from "../db/pool.js";
import { logAudit } from "../services/audit.service.js";

function canAccessServer(user, serverRow) {
  if (user.role === "admin") return true;
  return serverRow.owner_id === user.sub || serverRow.reseller_id === user.sub;
}

export async function listServers(req, res) {
  const user = req.user;

  const result =
    user.role === "admin"
      ? await query(
          `
            SELECT id, name, node, owner_id, reseller_id, cpu_limit, ram_limit_mb, disk_limit_mb, status, created_at
            FROM servers
            ORDER BY created_at DESC
          `
        )
      : await query(
          `
            SELECT id, name, node, owner_id, reseller_id, cpu_limit, ram_limit_mb, disk_limit_mb, status, created_at
            FROM servers
            WHERE reseller_id = $1 OR owner_id = $1
            ORDER BY created_at DESC
          `,
          [user.sub]
        );

  return res.json({ items: result.rows });
}

export async function createServer(req, res) {
  const user = req.user;
  const { name, node, ownerId, cpuLimit, ramLimitMb, diskLimitMb, status } = req.body;

  const effectiveOwner = user.role === "admin" ? ownerId ?? user.sub : user.sub;
  const resellerId = user.role === "admin" ? user.sub : user.sub;

  const created = await withTransaction(async (client) => {
    const result = await client.query(
      `
        INSERT INTO servers (name, node, owner_id, reseller_id, cpu_limit, ram_limit_mb, disk_limit_mb, status)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
        RETURNING id, name, node, owner_id, reseller_id, cpu_limit, ram_limit_mb, disk_limit_mb, status, created_at
      `,
      [name, node, effectiveOwner, resellerId, cpuLimit, ramLimitMb, diskLimitMb, status ?? "stopped"]
    );

    const row = result.rows[0];

    await client.query(
      `
        INSERT INTO server_startup (server_id)
        VALUES ($1)
        ON CONFLICT (server_id) DO NOTHING
      `,
      [row.id]
    );

    await client.query(
      `
        INSERT INTO audit_logs (actor_id, action, target_type, target_id, details)
        VALUES ($1, 'server.create', 'server', $2, $3)
      `,
      [user.sub, row.id, { name, node }]
    );

    return row;
  });

  return res.status(201).json({ item: created });
}

export async function powerAction(req, res) {
  const user = req.user;
  const { id } = req.params;
  const { action } = req.body;

  const serverResult = await query(`SELECT * FROM servers WHERE id = $1 LIMIT 1`, [id]);
  const server = serverResult.rows[0];
  if (!server) {
    return res.status(404).json({ message: "Server not found" });
  }

  if (!canAccessServer(user, server)) {
    return res.status(403).json({ message: "Forbidden" });
  }

  const nextStatus = action === "start" ? "running" : action === "stop" ? "stopped" : "restarting";
  await query(`UPDATE servers SET status = $1, updated_at = NOW() WHERE id = $2`, [nextStatus, id]);

  await logAudit({
    actorId: user.sub,
    action: `server.power.${action}`,
    targetType: "server",
    targetId: id,
    details: { previousStatus: server.status, nextStatus },
  });

  return res.json({ id, status: nextStatus, action });
}

export async function getResources(req, res) {
  const user = req.user;
  const { id } = req.params;

  const serverResult = await query(`SELECT * FROM servers WHERE id = $1 LIMIT 1`, [id]);
  const server = serverResult.rows[0];
  if (!server) {
    return res.status(404).json({ message: "Server not found" });
  }

  if (!canAccessServer(user, server)) {
    return res.status(403).json({ message: "Forbidden" });
  }

  const metrics = await query(
    `
      SELECT cpu_percent, ram_percent, disk_percent, observed_at
      FROM server_metrics
      WHERE server_id = $1
      ORDER BY observed_at DESC
      LIMIT 1
    `,
    [id]
  );

  const latest =
    metrics.rows[0] ??
    ({
      cpu_percent: 0,
      ram_percent: 0,
      disk_percent: 0,
      observed_at: new Date().toISOString(),
    });

  return res.json({ serverId: id, resources: latest });
}

export async function listFiles(req, res) {
  const user = req.user;
  const { id } = req.params;
  const path = req.query.path ?? "/";

  const serverResult = await query(`SELECT * FROM servers WHERE id = $1 LIMIT 1`, [id]);
  const server = serverResult.rows[0];
  if (!server) return res.status(404).json({ message: "Server not found" });
  if (!canAccessServer(user, server)) return res.status(403).json({ message: "Forbidden" });

  // Scaffold response: replace with real daemon SFTP/file API integration.
  return res.json({
    serverId: id,
    path,
    items: [
      { name: "server.properties", type: "file", size: 2.4, lastModified: new Date().toISOString() },
      { name: "logs", type: "directory", size: 0, lastModified: new Date().toISOString() },
    ],
  });
}

export async function listBackups(req, res) {
  const user = req.user;
  const { id } = req.params;
  const serverResult = await query(`SELECT * FROM servers WHERE id = $1 LIMIT 1`, [id]);
  const server = serverResult.rows[0];
  if (!server) return res.status(404).json({ message: "Server not found" });
  if (!canAccessServer(user, server)) return res.status(403).json({ message: "Forbidden" });

  const result = await query(
    `
      SELECT id, name, status, size_mb, created_at
      FROM server_backups
      WHERE server_id = $1
      ORDER BY created_at DESC
    `,
    [id]
  );

  return res.json({ items: result.rows });
}

export async function createBackup(req, res) {
  const user = req.user;
  const { id } = req.params;
  const { name } = req.body;
  const serverResult = await query(`SELECT * FROM servers WHERE id = $1 LIMIT 1`, [id]);
  const server = serverResult.rows[0];
  if (!server) return res.status(404).json({ message: "Server not found" });
  if (!canAccessServer(user, server)) return res.status(403).json({ message: "Forbidden" });

  const created = await query(
    `
      INSERT INTO server_backups (server_id, name, status, size_mb)
      VALUES ($1, $2, 'completed', 256)
      RETURNING id, name, status, size_mb, created_at
    `,
    [id, name]
  );

  await logAudit({
    actorId: user.sub,
    action: "server.backup.create",
    targetType: "server",
    targetId: id,
    details: { backupId: created.rows[0].id },
  });

  return res.status(201).json({ item: created.rows[0] });
}

export async function getStartup(req, res) {
  const user = req.user;
  const { id } = req.params;
  const serverResult = await query(`SELECT * FROM servers WHERE id = $1 LIMIT 1`, [id]);
  const server = serverResult.rows[0];
  if (!server) return res.status(404).json({ message: "Server not found" });
  if (!canAccessServer(user, server)) return res.status(403).json({ message: "Forbidden" });

  const result = await query(
    `
      SELECT docker_image, startup_command, updated_at
      FROM server_startup
      WHERE server_id = $1
      LIMIT 1
    `,
    [id]
  );

  if (!result.rows[0]) {
    return res.json({
      item: {
        docker_image: "ghcr.io/pterodactyl/yolks:java_17",
        startup_command: "java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar server.jar",
      },
    });
  }

  return res.json({ item: result.rows[0] });
}

export async function updateStartup(req, res) {
  const user = req.user;
  const { id } = req.params;
  const { dockerImage, startupCommand } = req.body;
  const serverResult = await query(`SELECT * FROM servers WHERE id = $1 LIMIT 1`, [id]);
  const server = serverResult.rows[0];
  if (!server) return res.status(404).json({ message: "Server not found" });
  if (!canAccessServer(user, server)) return res.status(403).json({ message: "Forbidden" });

  const updated = await query(
    `
      INSERT INTO server_startup (server_id, docker_image, startup_command, updated_at)
      VALUES ($1, $2, $3, NOW())
      ON CONFLICT (server_id)
      DO UPDATE SET docker_image = EXCLUDED.docker_image, startup_command = EXCLUDED.startup_command, updated_at = NOW()
      RETURNING docker_image, startup_command, updated_at
    `,
    [id, dockerImage, startupCommand]
  );

  await logAudit({
    actorId: user.sub,
    action: "server.startup.update",
    targetType: "server",
    targetId: id,
    details: { dockerImage },
  });

  return res.json({ item: updated.rows[0] });
}

export async function listAllocations(req, res) {
  const user = req.user;
  const { id } = req.params;
  const serverResult = await query(`SELECT * FROM servers WHERE id = $1 LIMIT 1`, [id]);
  const server = serverResult.rows[0];
  if (!server) return res.status(404).json({ message: "Server not found" });
  if (!canAccessServer(user, server)) return res.status(403).json({ message: "Forbidden" });

  const result = await query(
    `
      SELECT id, ip, port, is_primary, created_at
      FROM server_allocations
      WHERE server_id = $1
      ORDER BY is_primary DESC, created_at ASC
    `,
    [id]
  );

  return res.json({ items: result.rows });
}

export async function createAllocation(req, res) {
  const user = req.user;
  const { id } = req.params;
  const { ip, port } = req.body;
  const serverResult = await query(`SELECT * FROM servers WHERE id = $1 LIMIT 1`, [id]);
  const server = serverResult.rows[0];
  if (!server) return res.status(404).json({ message: "Server not found" });
  if (!canAccessServer(user, server)) return res.status(403).json({ message: "Forbidden" });

  const current = await query(`SELECT COUNT(*)::int AS total FROM server_allocations WHERE server_id = $1`, [id]);
  const isPrimary = current.rows[0].total === 0;

  const created = await query(
    `
      INSERT INTO server_allocations (server_id, ip, port, is_primary)
      VALUES ($1, $2, $3, $4)
      RETURNING id, ip, port, is_primary, created_at
    `,
    [id, ip, port, isPrimary]
  );

  await logAudit({
    actorId: user.sub,
    action: "server.allocation.create",
    targetType: "server",
    targetId: id,
    details: { ip, port },
  });

  return res.status(201).json({ item: created.rows[0] });
}

export async function listSubusers(req, res) {
  const user = req.user;
  const { id } = req.params;
  const serverResult = await query(`SELECT * FROM servers WHERE id = $1 LIMIT 1`, [id]);
  const server = serverResult.rows[0];
  if (!server) return res.status(404).json({ message: "Server not found" });
  if (!canAccessServer(user, server)) return res.status(403).json({ message: "Forbidden" });

  const result = await query(
    `
      SELECT id, email, permissions, created_at
      FROM server_subusers
      WHERE server_id = $1
      ORDER BY created_at DESC
    `,
    [id]
  );

  return res.json({ items: result.rows });
}

export async function createSubuser(req, res) {
  const user = req.user;
  const { id } = req.params;
  const { email, permissions } = req.body;
  const serverResult = await query(`SELECT * FROM servers WHERE id = $1 LIMIT 1`, [id]);
  const server = serverResult.rows[0];
  if (!server) return res.status(404).json({ message: "Server not found" });
  if (!canAccessServer(user, server)) return res.status(403).json({ message: "Forbidden" });

  const created = await query(
    `
      INSERT INTO server_subusers (server_id, email, permissions, created_by)
      VALUES ($1, $2, $3, $4)
      RETURNING id, email, permissions, created_at
    `,
    [id, email, permissions, user.sub]
  );

  await logAudit({
    actorId: user.sub,
    action: "server.subuser.create",
    targetType: "server",
    targetId: id,
    details: { email, permissionsCount: permissions.length },
  });

  return res.status(201).json({ item: created.rows[0] });
}