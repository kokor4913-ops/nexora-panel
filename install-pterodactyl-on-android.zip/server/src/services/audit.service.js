import { query } from "../db/pool.js";

export async function logAudit({ actorId, action, targetType, targetId, details }) {
  await query(
    `
      INSERT INTO audit_logs (actor_id, action, target_type, target_id, details)
      VALUES ($1, $2, $3, $4, $5)
    `,
    [actorId ?? null, action, targetType ?? null, targetId ?? null, details ?? null]
  );
}