CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('admin', 'reseller')),
  reseller_id UUID NULL,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS servers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  node TEXT NOT NULL,
  owner_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  reseller_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
  cpu_limit INTEGER NOT NULL,
  ram_limit_mb INTEGER NOT NULL,
  disk_limit_mb INTEGER NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('running', 'stopped', 'restarting')) DEFAULT 'stopped',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS server_metrics (
  id BIGSERIAL PRIMARY KEY,
  server_id UUID NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
  cpu_percent NUMERIC(5,2) NOT NULL DEFAULT 0,
  ram_percent NUMERIC(5,2) NOT NULL DEFAULT 0,
  disk_percent NUMERIC(5,2) NOT NULL DEFAULT 0,
  observed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS server_startup (
  server_id UUID PRIMARY KEY REFERENCES servers(id) ON DELETE CASCADE,
  docker_image TEXT NOT NULL DEFAULT 'ghcr.io/pterodactyl/yolks:java_17',
  startup_command TEXT NOT NULL DEFAULT 'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar server.jar',
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS server_allocations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  server_id UUID NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
  ip TEXT NOT NULL,
  port INTEGER NOT NULL CHECK (port > 0 AND port <= 65535),
  is_primary BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (ip, port)
);

CREATE TABLE IF NOT EXISTS server_backups (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  server_id UUID NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('queued', 'completed', 'failed')) DEFAULT 'queued',
  size_mb INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS server_subusers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  server_id UUID NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  permissions TEXT[] NOT NULL,
  created_by UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (server_id, email)
);

CREATE TABLE IF NOT EXISTS invoices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_name TEXT NOT NULL,
  amount_pkr NUMERIC(12,2) NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('pending', 'paid', 'rejected')) DEFAULT 'pending',
  created_by UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  note TEXT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id UUID NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  method TEXT NOT NULL,
  transaction_ref TEXT NOT NULL,
  screenshot_url TEXT NULL,
  verified_by UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  status TEXT NOT NULL CHECK (status IN ('paid', 'rejected')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS server_orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ordered_by UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  server_name TEXT NOT NULL,
  node TEXT NOT NULL,
  cpu_limit INTEGER NOT NULL,
  ram_limit_mb INTEGER NOT NULL,
  disk_limit_mb INTEGER NOT NULL,
  amount_pkr NUMERIC(12,2) NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('pending_payment', 'paid', 'rejected', 'provisioned')) DEFAULT 'pending_payment',
  note TEXT NULL,
  paid_at TIMESTAMPTZ NULL,
  provisioned_server_id UUID NULL REFERENCES servers(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS order_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES server_orders(id) ON DELETE CASCADE,
  transaction_id TEXT NOT NULL,
  sender_number TEXT NOT NULL,
  screenshot_url TEXT NULL,
  review_status TEXT NOT NULL CHECK (review_status IN ('pending', 'approved', 'rejected')) DEFAULT 'pending',
  reviewed_by UUID NULL REFERENCES users(id) ON DELETE SET NULL,
  admin_note TEXT NULL,
  reviewed_at TIMESTAMPTZ NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id BIGSERIAL PRIMARY KEY,
  actor_id UUID NULL REFERENCES users(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  target_type TEXT NULL,
  target_id TEXT NULL,
  details JSONB NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_servers_owner_id ON servers(owner_id);
CREATE INDEX IF NOT EXISTS idx_servers_reseller_id ON servers(reseller_id);
CREATE INDEX IF NOT EXISTS idx_metrics_server_id ON server_metrics(server_id);
CREATE INDEX IF NOT EXISTS idx_backups_server_id ON server_backups(server_id);
CREATE INDEX IF NOT EXISTS idx_allocations_server_id ON server_allocations(server_id);
CREATE INDEX IF NOT EXISTS idx_invoices_created_by ON invoices(created_by);
CREATE INDEX IF NOT EXISTS idx_orders_ordered_by ON server_orders(ordered_by);
CREATE INDEX IF NOT EXISTS idx_orders_status ON server_orders(status);
CREATE UNIQUE INDEX IF NOT EXISTS idx_order_transactions_transaction_id_unique ON order_transactions(LOWER(transaction_id));
CREATE UNIQUE INDEX IF NOT EXISTS idx_payments_transaction_ref_unique ON payments(LOWER(transaction_ref));
CREATE INDEX IF NOT EXISTS idx_audit_actor_id ON audit_logs(actor_id);