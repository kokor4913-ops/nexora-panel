import "dotenv/config";
import bcrypt from "bcryptjs";
import pg from "pg";

const { Pool } = pg;

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL is required");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function seed() {
  const adminPassword = process.env.SEED_ADMIN_PASSWORD ?? "Admin@12345";
  const resellerPassword = process.env.SEED_RESELLER_PASSWORD ?? "Reseller@12345";

  const [adminHash, resellerHash] = await Promise.all([
    bcrypt.hash(adminPassword, 12),
    bcrypt.hash(resellerPassword, 12),
  ]);

  const resellerResult = await pool.query(
    `
      INSERT INTO users (full_name, email, password_hash, role)
      VALUES ('Demo Reseller', 'reseller@nexora.local', $1, 'reseller')
      ON CONFLICT (email)
      DO UPDATE SET password_hash = EXCLUDED.password_hash
      RETURNING id
    `,
    [resellerHash]
  );

  const resellerId = resellerResult.rows[0].id;

  await pool.query(
    `
      INSERT INTO users (full_name, email, password_hash, role, reseller_id)
      VALUES ('Demo Admin', 'admin@nexora.local', $1, 'admin', $2)
      ON CONFLICT (email)
      DO UPDATE SET password_hash = EXCLUDED.password_hash, reseller_id = EXCLUDED.reseller_id
    `,
    [adminHash, resellerId]
  );

  console.log("Seed complete");
  console.log("Admin: admin@nexora.local", "Password:", adminPassword);
  console.log("Reseller: reseller@nexora.local", "Password:", resellerPassword);
}

seed()
  .catch((error) => {
    console.error(error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await pool.end();
  });