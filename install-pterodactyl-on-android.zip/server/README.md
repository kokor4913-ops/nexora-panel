# Nexora Backend API Scaffold

This scaffold gives you a production-oriented starting point for Admin + Reseller APIs similar to a Pterodactyl-style control panel backend.

## Included

- Express API with security middleware (helmet, cors, rate limit)
- JWT auth + RBAC (admin, reseller)
- PostgreSQL schema for users, servers, startup/network/backup/subuser modules, invoices, payments, order transactions, and audit logs
- Core endpoints for auth, server control modules, billing orders, EasyPaisa transaction verification, and audit logs
- Seed script for demo admin/reseller users

## Quick Start (Local)

1. Copy env file.
2. Create PostgreSQL database.
3. Run SQL schema.
4. Run seed script.
5. Start API.

Commands:

```bash
cp .env.example .env
psql "$DATABASE_URL" -f server/db/init.sql
node server/scripts/seed.mjs
node server/src/index.js
```

API base URL:

```text
http://localhost:4000/api/v1
```

## API Endpoints

- `POST /api/v1/auth/login`
- `GET /api/v1/auth/me`
- `GET /api/v1/servers`
- `POST /api/v1/servers`
- `POST /api/v1/servers/:id/power`
- `GET /api/v1/servers/:id/resources`
- `GET /api/v1/servers/:id/files`
- `GET /api/v1/servers/:id/backups`
- `POST /api/v1/servers/:id/backups`
- `GET /api/v1/servers/:id/startup`
- `PATCH /api/v1/servers/:id/startup`
- `GET /api/v1/servers/:id/network/allocations`
- `POST /api/v1/servers/:id/network/allocations`
- `GET /api/v1/servers/:id/subusers`
- `POST /api/v1/servers/:id/subusers`
- `POST /api/v1/billing/invoices`
- `POST /api/v1/billing/orders`
- `GET /api/v1/billing/orders`
- `POST /api/v1/billing/orders/:orderId/submit-transaction`
- `POST /api/v1/billing/orders/:orderId/verify-transaction`
- `POST /api/v1/billing/payments/easypaisa/verify`
- `GET /api/v1/audit-logs`

## EasyPaisa Transaction ID Flow

1. Reseller/Admin creates server order via `POST /billing/orders`.
2. Buyer pays to EasyPaisa number and submits `transactionId` via `POST /billing/orders/:orderId/submit-transaction`.
3. Admin reviews and approves/rejects via `POST /billing/orders/:orderId/verify-transaction`.
4. Approved payment marks order paid and can auto-provision a server.

## Production Notes

- Keep API behind Nginx reverse proxy with HTTPS.
- Use long random JWT secret and rotate periodically.
- Add Redis-backed queue for heavy actions (backups, sync, usage polling).
- Integrate a node daemon for real container lifecycle control.